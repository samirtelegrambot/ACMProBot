class Emoji:
    THUMBS_UP = "👍"
    THUMBS_DOWN = "👎"
    WARNING = "⚠️"
    INFO = "ℹ️"
    SUCCESS = "✅"
    ERROR = "❌"
    SETTINGS = "⚙️"
    CHANNEL = "📺"
    BATCH = "📦"
    SCHEDULE = "⏰"
    POST = "✍️"
    ADMIN = "👑"
    BACK = "🔙"


